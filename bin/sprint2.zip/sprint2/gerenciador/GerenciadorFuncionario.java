package sprint2.gerenciador;

import java.util.ArrayList;
import java.util.List;

import sprint2.model.Cargo;
import sprint2.model.CentroAutomotivo;
import sprint2.model.Funcionario;

public class GerenciadorFuncionario {
    private Funcionario funcionario;
    private List<Funcionario> funcionarios;

    public GerenciadorFuncionario(Funcionario funcionario) {
    	this.funcionario = funcionario;
    	this.funcionarios = new ArrayList<Funcionario>();
    }

    public void alterarCargo(Cargo novoCargo) {
        this.funcionario.setCargo(novoCargo);
    }

    public void alterarCentroAutomotivo(CentroAutomotivo novoCentroAutomotivo) {
        this.funcionario.setCentroAutomotivo(novoCentroAutomotivo);
    }
}
