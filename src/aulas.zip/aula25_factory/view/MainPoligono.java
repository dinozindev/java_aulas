package aula25_factory.view;

public class MainPoligono {
	
}
