package aula25_factory.model.interfaces;

public interface Poligono {
	public int getNumeroLados();
}
