package aula24_singleton;

public class TesteSingleton2 {
	public static void main(String[] args) {
		Singleton.getInstancia();
	}
}
