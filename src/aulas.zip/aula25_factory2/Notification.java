package aula25_factory2;

public interface Notification {
	public void notifyUser();
}
